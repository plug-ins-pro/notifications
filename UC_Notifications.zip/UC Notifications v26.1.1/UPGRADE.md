# UC - Notifications — upgrade notes

## What changed

As of **v26.1.0** the plug-in's internal name is `UNITEDCODES_NOTIFICATIONS`. Versions up to and including
v23.1 used `UC_NOTIFICATIONS`. This is a permanent change: all current and future versions use
`UNITEDCODES_NOTIFICATIONS`.

APEX identifies a plug-in by its internal name, so a new version is **not** recognised as an update of the
old one. Upgrading from v23.1 or older therefore needs the one-time migration below. Once you are on
v26.1.0 or later, all further upgrades install over the previous version normally, with your dynamic
actions and their settings untouched.

## What you will see when upgrading from v23.1 or older

**On APEX 26.1 and later** the import stops with:

```
ORA-00001: unique constraint (APEX_260100.WWV_FLOW_PLUGIN_APEXLANG_UK) violated
```

Nothing is installed and nothing in your application is changed — you are still on your old version.

**On APEX 24.2 and earlier** the import *succeeds*, but it adds a **second** plug-in instead of replacing
the old one. Both are called *UC - Notifications* in the plug-in list. Your existing dynamic actions stay
attached to the old plug-in and keep running the old version, so the update appears to have worked while it
has not. Please follow the migration below in that case as well.

## Migration

There are three ways to do it. **Option B** is the one to pick if your applications contain many dynamic
actions, because it needs no dynamic action edits at all.

### Option A — delete, import, re-select the action

1. **Shared Components → Plug-ins** in your application.
2. Delete the plug-in **UC - Notifications** whose internal name is `UC_NOTIFICATIONS`.
3. Import `dynamic_action_plugin_unitedcodes_notifications.sql`
   (App Builder → Shared Components → Plug-ins → Import). This installs
   `UNITEDCODES_NOTIFICATIONS`.
4. Open every dynamic action that used the plug-in and select the action **UC - Notifications** again.
   Check the settings of each action afterwards and re-enter them where they are empty.

Dynamic actions reference a plug-in by its internal name, which is why step 4 is necessary — and also why
no further upgrade will ever require it again.

If your application has published translations, re-publish them after the import.

### Option B — rename the plug-in inside an application export (no dynamic action edits)

Because a dynamic action stores the plug-in's internal name as text, you can change it everywhere at once by
renaming it in an application export and importing that back. One search-and-replace per application replaces
what would otherwise be one edit per dynamic action.

1. **App Builder → your application → Export / Import → Export** and export the application as a single SQL
   file. Do this immediately before the next step, because importing replaces the application.
2. Open the exported file in a text editor and replace every occurrence of `UC_NOTIFICATIONS` with
   `UNITEDCODES_NOTIFICATIONS`. Nothing else needs to change.
3. Check the number of replacements before saving. It should be **1 + the number of dynamic actions that use
   the plug-in**: one for the plug-in itself, and one `PLUGIN_UC_NOTIFICATIONS` reference per dynamic action.
   A very different number means the wrong text was matched — do not save.
4. Import the edited file over the same application (**Export / Import → Import**, keeping the application ID).

The export already contains the plug-in, so this single import performs the whole upgrade — no separate
plug-in import is needed afterwards, and all later versions install over it normally.

Please note:

- Importing replaces the entire application, so anything changed since the export in step 1 is lost. Try it on
  a copy of the application first.
- Repeat per application. Applications that do not use the plug-in need nothing.

### Option C — run both versions side by side

If you would rather migrate the dynamic actions one at a time instead of all at once, you can keep both
versions installed for a while:

1. **Shared Components → Plug-ins → UC - Notifications** (the old `UC_NOTIFICATIONS` one). Change its
   **Name** to e.g. *UC - Notifications (old)* and its **APEXlang Name** to e.g. `ucNotificationsOld`, then
   apply the changes.
2. Import the new version. It installs alongside the old one, and both appear in the plug-in list.
3. Move your dynamic actions over to **UC - Notifications** one by one.
4. When no dynamic action uses the old plug-in any more, delete it.

## Which version do I have?

**Shared Components → Plug-ins → UC - Notifications** shows both the version and the internal name.
`UNITEDCODES_NOTIFICATIONS` means you are on v26.1.0 or later and no migration is needed.

## Sample application

The bundled sample application already uses `UNITEDCODES_NOTIFICATIONS`. If you copy examples from it into
your own application, make sure the new plug-in is installed there.

